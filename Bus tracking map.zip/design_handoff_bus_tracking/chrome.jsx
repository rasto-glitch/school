// Chrome: top header (school brand + notification bell) and bottom tab bar,
// rendered as translucent glass overlays so the underlying map shows through.
// Mirrors ParentTabs.tsx — Feed, Learn, Bus (active), Chat, Me.

function TopHeader({ dark = false, accent = '#4F46E5', unreadCount = 3 }) {
  const text = dark ? '#F8FAFC' : '#0F172A';
  const sub = dark ? '#94A3B8' : '#64748B';
  return (
    <div style={{
      position: 'absolute', top: 54, left: 0, right: 0, height: 56,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 16px', zIndex: 30,
      // glass plate
      background: dark ? 'rgba(13,19,28,0.72)' : 'rgba(255,255,255,0.78)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderBottom: dark ? '0.5px solid rgba(255,255,255,0.08)' : '0.5px solid rgba(15,23,42,0.08)',
    }}>
      {/* school brand */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 34, height: 34, borderRadius: 10,
          background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 4px 12px ${accent}55`,
          fontWeight: 800, fontSize: 14, color: '#fff', letterSpacing: -0.5,
        }}>LE</div>
        <div style={{ lineHeight: 1.1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: text, letterSpacing: -0.2 }}>Lincoln Elementary</div>
          <div style={{ fontSize: 11, color: sub, fontWeight: 500, marginTop: 2 }}>Parent</div>
        </div>
      </div>
      {/* notification bell */}
      <button style={{
        width: 36, height: 36, borderRadius: 18,
        background: dark ? 'rgba(255,255,255,0.12)' : 'rgba(79,70,229,0.10)',
        border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', position: 'relative',
      }}>
        <BellIcon size={17} color={dark ? '#FFFFFF' : accent} />
        {unreadCount > 0 && (
          <div style={{
            position: 'absolute', top: -2, right: -2, minWidth: 14, height: 14, borderRadius: 7,
            background: '#EF4444', color: '#fff', fontSize: 8, fontWeight: 800,
            display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px',
          }}>{unreadCount > 99 ? '99+' : unreadCount}</div>
        )}
      </button>
    </div>
  );
}

// Bottom tab bar — bus tab active. Indicator bar (32×2) above active tab.
function BottomTabs({ dark = false, accent = '#4F46E5' }) {
  const mutedTxt = dark ? 'rgba(255,255,255,0.55)' : '#94A3B8';
  const activeTxt = dark ? '#FFFFFF' : accent;
  const activeIcon = dark ? '#FFFFFF' : accent;
  const inactiveIcon = dark ? 'rgba(255,255,255,0.55)' : '#94A3B8';

  // 5 tabs — Feed, Learn, Bus (active), Chat, Me
  const tabs = [
    { id: 'feed',  label: 'Dashboard', Icon: HouseIcon,   badge: 0 },
    { id: 'learn', label: 'Learn',     Icon: GradCapIcon, badge: 2 },
    { id: 'bus',   label: 'Bus',       Icon: BusIcon,     badge: 0, active: true },
    { id: 'chat',  label: 'Chat',      Icon: ChatTabIcon, badge: 1 },
    { id: 'me',    label: 'Me',        Icon: UserIcon,    badge: 0 },
  ];

  const indicatorIndex = tabs.findIndex(t => t.active);
  const totalH = 76; // 60 nav + 16 safe-area padding above home indicator

  return (
    <div style={{
      position: 'absolute', bottom: 18, left: 0, right: 0, height: totalH,
      zIndex: 30,
      background: dark ? 'rgba(13,19,28,0.78)' : 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(22px) saturate(180%)',
      WebkitBackdropFilter: 'blur(22px) saturate(180%)',
      borderTop: dark ? '0.5px solid rgba(255,255,255,0.08)' : '0.5px solid rgba(15,23,42,0.08)',
    }}>
      {/* Active indicator strip — sits at very top of bar */}
      <div style={{
        position: 'absolute', top: 0, left: `${(indicatorIndex / 5) * 100}%`,
        width: '20%', display: 'flex', justifyContent: 'center',
      }}>
        <div style={{ width: 32, height: 2, borderRadius: 1, background: activeTxt }} />
      </div>

      <div style={{ display: 'flex', height: 60, paddingTop: 8 }}>
        {tabs.map(t => {
          const isActive = !!t.active;
          const color = isActive ? activeIcon : inactiveIcon;
          const labelColor = isActive ? activeTxt : mutedTxt;
          const Glyph = t.Icon;
          return (
            <div key={t.id} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
              justifyContent: 'flex-start', gap: 3, position: 'relative',
            }}>
              <div style={{ position: 'relative' }}>
                {/* Active tab — filled white circle behind */}
                {isActive && (
                  <div style={{
                    position: 'absolute', inset: -3,
                    background: dark ? 'rgba(255,255,255,0.10)' : `${accent}18`,
                    borderRadius: 10,
                  }} />
                )}
                <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 22 }}>
                  <Glyph
                    size={22}
                    color={color}
                    fill={isActive ? color : 'none'}
                    fillOpacity={isActive ? (Glyph === BusIcon ? 1 : 0.18) : 0}
                  />
                </div>
                {t.badge > 0 && (
                  <div style={{
                    position: 'absolute', top: -5, right: -7,
                    minWidth: 14, height: 14, borderRadius: 7,
                    background: '#EF4444', color: '#fff', fontSize: 8, fontWeight: 800,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px',
                  }}>{t.badge}</div>
                )}
              </div>
              <div style={{ fontSize: 11, fontWeight: 500, color: labelColor, letterSpacing: -0.1 }}>{t.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Layout constants used by every variation so overlay cards know where the
// usable map area starts/ends.
const CHROME = {
  HEADER_TOP: 54,
  HEADER_HEIGHT: 56,
  HEADER_BOTTOM: 110,        // 54 + 56
  TAB_TOP: 780,              // bottom: 18 + height 76 = 874-94 = 780
  TAB_BOTTOM: 874 - 18,      // 856
};

Object.assign(window, { TopHeader, BottomTabs, CHROME });
