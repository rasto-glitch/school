// Stylized map background. Renders streets, blocks, a park, water, plus
// the bus + pickup markers and an optional dashed route. SVG only — this
// is a believable map placeholder, NOT a real tile renderer.

function MapBackground({
  dark = false,
  accent = '#4F46E5',
  busPos = { x: 0.62, y: 0.34 },
  parentPos = { x: 0.32, y: 0.7 },
  showRoute = true,
  width = 402,
  height = 874,
}) {
  // Tile palette
  const palette = dark ? {
    land:    '#1B232E',
    block:   '#252F3D',
    blockAlt:'#2A3547',
    park:    '#1F3328',
    parkLine:'#284A35',
    water:   '#1A2E47',
    street:  '#0F141C',
    streetMinor: '#2E3947',
    streetEdge:  '#11161E',
    label:   'rgba(255,255,255,0.55)',
  } : {
    land:    '#E9ECF1',
    block:   '#F4F6F9',
    blockAlt:'#EEF1F5',
    park:    '#D8E8D2',
    parkLine:'#C2D9B8',
    water:   '#CCDFEC',
    street:  '#FFFFFF',
    streetMinor: '#F8FAFC',
    streetEdge:  '#DDE2E9',
    label:   'rgba(30,42,60,0.45)',
  };

  // Convert fractional position to px
  const bx = busPos.x * width;
  const by = busPos.y * height;
  const px = parentPos.x * width;
  const py = parentPos.y * height;

  // Route as a smooth curve via control point
  const cx = (bx + px) / 2 + (dark ? -28 : -36);
  const cy = (by + py) / 2 + 70;
  const routeD = `M ${bx} ${by} Q ${cx} ${cy} ${px} ${py}`;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}
         style={{ position: 'absolute', inset: 0, display: 'block' }}>
      {/* base land */}
      <rect width={width} height={height} fill={palette.land} />

      {/* WATER strip — diagonal river top-right */}
      <path
        d={`M ${width - 60} 0 L ${width} 0 L ${width} 180 L ${width - 90} 240 L ${width - 200} 200 Z`}
        fill={palette.water}
      />
      <path
        d={`M ${width - 200} 200 Q ${width - 150} 230 ${width - 90} 240`}
        fill="none" stroke={palette.streetEdge} strokeWidth="0.5" opacity="0.4"
      />

      {/* PARK — green block bottom-left */}
      <rect x="-10" y={height - 320} width="170" height="200" fill={palette.park} rx="2" />
      {/* park crosshatch */}
      <g opacity="0.55">
        {[0,1,2,3,4].map(i => (
          <line key={i} x1={-10 + i*40} y1={height - 320} x2={-10 + i*40 + 60} y2={height - 120}
                stroke={palette.parkLine} strokeWidth="1" />
        ))}
      </g>

      {/* CITY BLOCKS — varied rectangles giving a believable urban grid */}
      {[
        // top band
        [20, 80, 90, 110], [125, 80, 70, 110], [205, 80, 90, 110],
        [20, 205, 130, 90], [165, 205, 60, 90], [240, 205, 60, 90],
        // middle band
        [20, 310, 80, 130], [115, 310, 110, 130], [240, 310, 80, 130], [335, 310, 80, 130],
        [20, 460, 110, 80], [145, 460, 80, 80], [240, 460, 130, 80],
        // lower band — outside park
        [180, 560, 90, 100], [285, 560, 130, 100],
        [180, 680, 70, 90], [265, 680, 100, 90], [380, 680, 50, 90],
        // far right
        [340, 80, 80, 130], [340, 460, 80, 80],
      ].map(([x, y, w, h], i) => (
        <rect key={`blk-${i}`} x={x} y={y} width={w} height={h}
              fill={i % 3 === 0 ? palette.blockAlt : palette.block}
              rx="3"
              opacity={dark ? 0.92 : 1} />
      ))}

      {/* STREETS — major horizontals */}
      {[60, 190, 295, 445, 545, 665, 785].map((y, i) => (
        <g key={`hs-${i}`}>
          <line x1="0" y1={y} x2={width} y2={y}
                stroke={palette.streetEdge} strokeWidth="14" opacity={dark ? 0.6 : 1} />
          <line x1="0" y1={y} x2={width} y2={y}
                stroke={palette.street} strokeWidth="11" />
        </g>
      ))}
      {/* STREETS — major verticals */}
      {[110, 230, 325, 425].map((x, i) => (
        <g key={`vs-${i}`}>
          <line x1={x} y1="0" x2={x} y2={height}
                stroke={palette.streetEdge} strokeWidth="12" opacity={dark ? 0.6 : 1} />
          <line x1={x} y1="0" x2={x} y2={height}
                stroke={palette.street} strokeWidth="9" />
        </g>
      ))}

      {/* minor streets */}
      <line x1="0" y1="370" x2={width} y2="370" stroke={palette.streetMinor} strokeWidth="5" opacity={dark ? 0.6 : 0.9} />
      <line x1="160" y1="0" x2="160" y2={height} stroke={palette.streetMinor} strokeWidth="5" opacity={dark ? 0.6 : 0.9} />

      {/* diagonal street through the lower park edge */}
      <g>
        <line x1="160" y1={height - 320} x2={width - 60} y2={height}
              stroke={palette.streetEdge} strokeWidth="12" opacity={dark ? 0.6 : 1} />
        <line x1="160" y1={height - 320} x2={width - 60} y2={height}
              stroke={palette.street} strokeWidth="9" />
      </g>

      {/* Faint street labels for realism */}
      <g fontFamily="-apple-system, system-ui, sans-serif" fontSize="9" fill={palette.label} fontWeight="500">
        <text x={width / 2} y="55" textAnchor="middle">Maple Ave</text>
        <text x="105" y="395" transform="rotate(-90 105 395)" textAnchor="middle">5th St</text>
        <text x={width / 2} y="660" textAnchor="middle">Park Rd</text>
        <text x="80" y={height - 220} textAnchor="middle">Linden Park</text>
      </g>

      {/* ROUTE */}
      {showRoute && (
        <>
          <path d={routeD} fill="none" stroke={dark ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.12)'} strokeWidth="9" strokeLinecap="round" />
          <path d={routeD} fill="none" stroke={accent} strokeWidth="5" strokeLinecap="round" strokeDasharray="2 8" opacity="0.95">
            <animate attributeName="stroke-dashoffset" from="0" to="-40" dur="2s" repeatCount="indefinite" />
          </path>
        </>
      )}

      {/* PARENT PIN (pickup location) */}
      <g transform={`translate(${px} ${py})`}>
        {/* shadow */}
        <ellipse cx="0" cy="6" rx="14" ry="3.5" fill="rgba(0,0,0,0.18)" />
        {/* outer ring */}
        <circle cx="0" cy="-2" r="14" fill={dark ? '#1B232E' : '#FFFFFF'} stroke={accent} strokeWidth="3" />
        {/* dot */}
        <circle cx="0" cy="-2" r="6" fill={accent} />
      </g>

      {/* BUS MARKER */}
      <g transform={`translate(${bx} ${by})`}>
        {/* pulse ring */}
        <circle cx="0" cy="0" r="22" fill={accent} opacity="0.18">
          <animate attributeName="r" from="20" to="32" dur="1.8s" repeatCount="indefinite" />
          <animate attributeName="opacity" from="0.25" to="0" dur="1.8s" repeatCount="indefinite" />
        </circle>
        {/* shadow */}
        <ellipse cx="0" cy="20" rx="18" ry="4" fill="rgba(0,0,0,0.22)" />
        {/* body */}
        <circle cx="0" cy="0" r="20" fill={accent} stroke={dark ? '#0B0F14' : '#FFFFFF'} strokeWidth="3" />
        {/* bus glyph */}
        <g transform="translate(-9 -9)" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="2.5" width="14" height="11" rx="2" />
          <line x1="2" y1="9" x2="16" y2="9" />
          <circle cx="5.5" cy="14.5" r="1.2" fill="#fff" />
          <circle cx="12.5" cy="14.5" r="1.2" fill="#fff" />
          <line x1="6" y1="5" x2="6" y2="7.5" />
          <line x1="12" y1="5" x2="12" y2="7.5" />
        </g>
      </g>
    </svg>
  );
}

window.MapBackground = MapBackground;
