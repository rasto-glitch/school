// Tiny inline icon set — lucide-style, 1.75 stroke. Each accepts size + color.

const Icon = (paths, vb = '0 0 24 24') => ({ size = 18, color = 'currentColor', strokeWidth = 1.75, fill = 'none', ...rest }) => (
  <svg width={size} height={size} viewBox={vb} fill={fill} stroke={color}
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {paths}
  </svg>
);

const BusIcon = Icon(<>
  <path d="M8 6v6" /><path d="M16 6v6" /><path d="M2 12h20" />
  <path d="M18 18h2a1 1 0 0 0 1-1V8a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v9a1 1 0 0 0 1 1h2" />
  <circle cx="7" cy="18" r="2" /><circle cx="17" cy="18" r="2" />
</>);
const PhoneIcon = Icon(
  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
);
const MessageIcon = Icon(
  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
);
const ChevronLeft = Icon(<polyline points="15 18 9 12 15 6" />);
const ChevronDown = Icon(<polyline points="6 9 12 15 18 9" />);
const ChevronRight = Icon(<polyline points="9 18 15 12 9 6" />);
const ShieldIcon = Icon(<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />);
const ClockIcon = Icon(<><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></>);
const NavigationIcon = Icon(<polygon points="3 11 22 2 13 21 11 13 3 11" />);
const UserIcon = Icon(<><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></>);
const MapPinIcon = Icon(<><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></>);
const RefreshIcon = Icon(<><polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" /></>);
const MoreIcon = Icon(<><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" /></>);
const StarIcon = Icon(<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />, '0 0 24 24');
const CheckIcon = Icon(<polyline points="20 6 9 17 4 12" />);
const AlertIcon = Icon(<><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></>);
const ZapIcon = Icon(<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />);
const BellIcon = Icon(<><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" /><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" /></>);
const HouseIcon = Icon(<><path d="M3 12L12 4l9 8" /><path d="M5 10v10h14V10" /><path d="M10 20v-6h4v6" /></>);
const GradCapIcon = Icon(<><path d="M2 8l10-4 10 4-10 4L2 8z" /><path d="M6 10v5c0 1.5 2.5 3 6 3s6-1.5 6-3v-5" /></>);
const ChatTabIcon = Icon(<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />);

Object.assign(window, {
  BusIcon, PhoneIcon, MessageIcon, ChevronLeft, ChevronDown, ChevronRight,
  ShieldIcon, ClockIcon, NavigationIcon, UserIcon, MapPinIcon, RefreshIcon,
  MoreIcon, StarIcon, CheckIcon, AlertIcon, ZapIcon,
  BellIcon, HouseIcon, GradCapIcon, ChatTabIcon,
});
