// ─────────────────────────────────────────────────────────────
// Shared mock data + helpers
// ─────────────────────────────────────────────────────────────

const STATE_LABELS = {
  en_route:    { label: 'En route',         eta: '8:14 AM', minutes: 4,  detail: 'Bus is 0.8 mi away · 3 stops ahead' },
  arriving:    { label: 'Arriving soon',    eta: '8:11 AM', minutes: 1,  detail: 'Bus turning onto Maple Ave' },
  boarded:     { label: 'On the bus',       eta: '8:35 AM', minutes: 18, detail: 'Heading to Lincoln Elementary' },
  dropped_off: { label: 'Dropped off',      eta: '8:23 AM', minutes: 0,  detail: 'Arrived at Lincoln Elementary' },
};

const KIDS = [
  { id: 'maya', name: 'Maya',  initials: 'M', color: '#F472B6', boarded: true },
  { id: 'leo',  name: 'Leo',   initials: 'L', color: '#60A5FA', boarded: true },
];

const DRIVER = {
  name: 'Sarah Chen',
  role: 'Driver · Bus #B‑204',
  bus: 'B‑204',
  rating: 4.9,
  trips: 1284,
  initials: 'SC',
};

// State badge color helper
function stateAccent(state, accent) {
  if (state === 'arriving') return '#F59E0B';
  if (state === 'dropped_off') return '#10B981';
  return accent;
}

// ─────────────────────────────────────────────────────────────
// Reusable bits
// ─────────────────────────────────────────────────────────────

function Avatar({ initials, color, size = 36, dark, ring }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: color || (dark ? '#3B4658' : '#E5E9EF'),
      color: '#fff', fontWeight: 700, fontSize: size * 0.4,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
      boxShadow: ring ? `0 0 0 3px ${ring}, 0 2px 8px rgba(0,0,0,0.18)` : '0 2px 8px rgba(0,0,0,0.18)',
      letterSpacing: 0.2,
    }}>{initials}</div>
  );
}

function PingDot({ color }) {
  return (
    <span style={{
      position: 'relative', display: 'inline-flex',
      width: 8, height: 8, alignItems: 'center', justifyContent: 'center',
    }}>
      <span style={{
        position: 'absolute', inset: -4, borderRadius: '50%',
        background: color, opacity: 0.25,
        animation: 'busPulse 1.6s ease-out infinite',
      }} />
      <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, position: 'relative' }} />
    </span>
  );
}

// Stacked kid avatars
function KidStack({ dark, size = 28 }) {
  return (
    <div style={{ display: 'flex' }}>
      {KIDS.map((k, i) => (
        <div key={k.id} style={{ marginLeft: i === 0 ? 0 : -10 }}>
          <Avatar initials={k.initials} color={k.color} size={size} dark={dark} ring={dark ? '#1B232E' : '#FFFFFF'} />
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 1 — Floating cards · Light · Minimal
// ─────────────────────────────────────────────────────────────
function V1FloatingLight({ state = 'en_route', accent = '#4F46E5' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#0F172A' }}>
      <MapBackground dark={false} accent={accent} showRoute={state !== 'dropped_off'} />

      {/* TOP FLOATING HEADER — glass pill */}
      <div style={{ position: 'absolute', top: 122, left: 16, right: 16, display: 'flex', gap: 10 }}>
        <button style={glassPillBtn(false)}>
          <ChevronLeft size={18} color="#0F172A" />
        </button>
        <div style={{
          flex: 1, ...glassCard(false),
          padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <KidStack dark={false} size={26} />
          <div style={{ lineHeight: 1.15 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#0F172A' }}>Maya & Leo</div>
            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 500 }}>Both on Bus B‑204</div>
          </div>
        </div>
        <button style={glassPillBtn(false)}>
          <RefreshIcon size={17} color="#0F172A" />
        </button>
      </div>

      {/* FLOATING ETA — top right */}
      <div style={{
        position: 'absolute', top: 188, right: 16,
        ...glassCard(false),
        padding: '12px 14px', minWidth: 124,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: sAccent }}>
            {s.label}
          </span>
        </div>
        <div style={{ fontSize: 34, fontWeight: 800, color: '#0F172A', lineHeight: 1, letterSpacing: -1 }}>
          {s.minutes}<span style={{ fontSize: 14, fontWeight: 600, color: '#64748B', marginLeft: 4 }}>min</span>
        </div>
        <div style={{ fontSize: 11, color: '#64748B', marginTop: 4, fontWeight: 500 }}>arrives {s.eta}</div>
      </div>

      {/* DRIVER CARD — bottom */}
      <div style={{
        position: 'absolute', bottom: 110, left: 16, right: 16,
        ...glassCard(false),
        padding: 14,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Avatar initials={DRIVER.initials} color={accent} size={44} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0F172A' }}>{DRIVER.name}</div>
            <div style={{ fontSize: 12, color: '#64748B', fontWeight: 500, marginTop: 1 }}>{DRIVER.role}</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={iconCircleBtn(false)}>
              <MessageIcon size={17} color="#0F172A" />
            </button>
            <button style={{ ...iconCircleBtn(false), background: accent, border: 'none' }}>
              <PhoneIcon size={17} color="#fff" />
            </button>
          </div>
        </div>
      </div>
      <TopHeader dark={false} accent={accent} />
      <BottomTabs dark={false} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 2 — Bottom sheet · Light · Friendly
// ─────────────────────────────────────────────────────────────
function V2SheetLight({ state = 'en_route', accent = '#4F46E5' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#0F172A' }}>
      <MapBackground dark={false} accent={accent} showRoute={state !== 'dropped_off'} />

      {/* TOP — back + child selector pill */}
      <div style={{ position: 'absolute', top: 122, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
        <button style={glassPillBtn(false)}>
          <ChevronLeft size={18} color="#0F172A" />
        </button>
        <div style={{ ...glassCard(false), padding: '8px 14px 8px 8px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <KidStack dark={false} size={26} />
          <span style={{ fontSize: 13, fontWeight: 700, color: '#0F172A' }}>Both kids</span>
          <ChevronDown size={14} color="#64748B" />
        </div>
        <button style={glassPillBtn(false)}>
          <MoreIcon size={18} color="#0F172A" />
        </button>
      </div>

      {/* BOTTOM SHEET */}
      <div style={{
        position: 'absolute', bottom: 94, left: 0, right: 0,
        background: '#FFFFFF',
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        boxShadow: '0 -12px 40px rgba(15,23,42,0.12)',
        padding: '12px 20px 20px',
      }}>
        {/* drag handle */}
        <div style={{ width: 38, height: 5, borderRadius: 3, background: '#CBD5E1', margin: '0 auto 14px' }} />

        {/* status row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 12, fontWeight: 700, color: sAccent, textTransform: 'uppercase', letterSpacing: 0.6 }}>
            {s.label}
          </span>
        </div>

        {/* big eta */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 4 }}>
          {state === 'dropped_off' ? (
            <span style={{ fontSize: 48, fontWeight: 800, color: '#0F172A', letterSpacing: -1.5, lineHeight: 1 }}>
              At school
            </span>
          ) : (
            <>
              <span style={{ fontSize: 64, fontWeight: 800, color: '#0F172A', letterSpacing: -2, lineHeight: 1 }}>
                {s.minutes}
              </span>
              <span style={{ fontSize: 22, fontWeight: 600, color: '#64748B' }}>min away</span>
            </>
          )}
        </div>
        <div style={{ fontSize: 14, color: '#64748B', marginBottom: 18, fontWeight: 500 }}>
          Arrives at <span style={{ color: '#0F172A', fontWeight: 700 }}>{s.eta}</span> · {s.detail.split('·')[0].trim()}
        </div>

        {/* driver row */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          background: '#F4F6F9', borderRadius: 18, padding: 12, marginBottom: 12,
        }}>
          <Avatar initials={DRIVER.initials} color={accent} size={42} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0F172A' }}>{DRIVER.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
              <StarIcon size={11} color="#F59E0B" fill="#F59E0B" />
              <span style={{ fontSize: 12, color: '#64748B', fontWeight: 500 }}>{DRIVER.rating} · {DRIVER.trips} trips</span>
            </div>
          </div>
          <div style={{
            background: '#FFFFFF', borderRadius: 999, padding: '6px 10px',
            display: 'flex', alignItems: 'center', gap: 5,
            border: '1px solid #E5E9EF',
          }}>
            <BusIcon size={13} color={accent} />
            <span style={{ fontSize: 12, fontWeight: 700, color: accent }}>{DRIVER.bus}</span>
          </div>
        </div>

        {/* action buttons */}
        <div style={{ display: 'flex', gap: 10 }}>
          <button style={{
            flex: 1, height: 50, borderRadius: 16, border: '1.5px solid #E5E9EF',
            background: '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            fontSize: 14, fontWeight: 700, color: '#0F172A', cursor: 'pointer',
          }}>
            <MessageIcon size={17} color="#0F172A" />
            Message
          </button>
          <button style={{
            flex: 1, height: 50, borderRadius: 16, border: 'none',
            background: accent, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            fontSize: 14, fontWeight: 700, cursor: 'pointer',
            boxShadow: `0 8px 22px ${accent}55`,
          }}>
            <PhoneIcon size={17} color="#fff" />
            Call driver
          </button>
        </div>
      </div>
      <TopHeader dark={false} accent={accent} />
      <BottomTabs dark={false} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 3 — Top banner + Action bar · Light · Utility
// ─────────────────────────────────────────────────────────────
function V3BannerLight({ state = 'en_route', accent = '#4F46E5' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#0F172A' }}>
      <MapBackground dark={false} accent={accent} showRoute={state !== 'dropped_off'} />

      {/* TOP BANNER — full width, square corners on top, rounded bottom */}
      <div style={{
        position: 'absolute', top: 122, left: 12, right: 12,
        background: '#FFFFFF',
        paddingTop: 4,
        boxShadow: '0 6px 24px rgba(15,23,42,0.10)',
        borderRadius: 18,
      }}>
        {/* status strip */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 18px 0' }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 11, fontWeight: 700, color: sAccent, textTransform: 'uppercase', letterSpacing: 0.6 }}>
            {s.label}
          </span>
          <span style={{ marginLeft: 'auto', fontSize: 11, color: '#64748B', fontWeight: 600 }}>
            Updated 12s ago
          </span>
        </div>

        <div style={{ padding: '4px 18px 16px', display: 'flex', alignItems: 'flex-end', gap: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 600, marginBottom: 2 }}>ARRIVES</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <div style={{ fontSize: 34, fontWeight: 800, color: '#0F172A', letterSpacing: -1, lineHeight: 1 }}>
                {s.eta}
              </div>
              {state !== 'dropped_off' && (
                <div style={{
                  background: sAccent + '18', color: sAccent,
                  borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 700,
                }}>
                  in {s.minutes} min
                </div>
              )}
            </div>
            <div style={{ fontSize: 12, color: '#64748B', marginTop: 4, fontWeight: 500 }}>{s.detail}</div>
          </div>
          {/* kids col */}
          <div style={{ textAlign: 'right' }}>
            <KidStack dark={false} size={28} />
            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 600, marginTop: 4 }}>2 onboard</div>
          </div>
        </div>
      </div>

      {/* BOTTOM ACTION BAR */}
      <div style={{
        position: 'absolute', bottom: 100, left: 12, right: 12,
        background: '#FFFFFF',
        borderRadius: 18,
        boxShadow: '0 -6px 24px rgba(15,23,42,0.10)',
        padding: '14px 18px 14px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <Avatar initials={DRIVER.initials} color={accent} size={40} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#0F172A' }}>{DRIVER.name}</div>
            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 500, marginTop: 1 }}>
              Driver · License DLR‑4421
            </div>
          </div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 4,
            background: '#F1F5F9', borderRadius: 8, padding: '5px 9px',
            fontSize: 11, fontWeight: 700, color: '#0F172A',
          }}>
            <BusIcon size={12} color="#0F172A" />
            {DRIVER.bus}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={squareBtn(false)}>
            <PhoneIcon size={16} color="#0F172A" />
            <span>Call</span>
          </button>
          <button style={squareBtn(false)}>
            <MessageIcon size={16} color="#0F172A" />
            <span>Text</span>
          </button>
          <button style={squareBtn(false)}>
            <ShieldIcon size={16} color="#EF4444" />
            <span style={{ color: '#EF4444' }}>Report</span>
          </button>
        </div>
      </div>
      <TopHeader dark={false} accent={accent} />
      <BottomTabs dark={false} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 4 — Floating cards · Dark · Minimal
// ─────────────────────────────────────────────────────────────
function V4FloatingDark({ state = 'en_route', accent = '#818CF8' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#F8FAFC' }}>
      <MapBackground dark={true} accent={accent} showRoute={state !== 'dropped_off'} />

      <div style={{ position: 'absolute', top: 122, left: 16, right: 16, display: 'flex', gap: 10 }}>
        <button style={glassPillBtn(true)}>
          <ChevronLeft size={18} color="#F8FAFC" />
        </button>
        <div style={{
          flex: 1, ...glassCard(true),
          padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <KidStack dark={true} size={26} />
          <div style={{ lineHeight: 1.15 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#F8FAFC' }}>Maya & Leo</div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 500 }}>Both on Bus B‑204</div>
          </div>
        </div>
        <button style={glassPillBtn(true)}>
          <RefreshIcon size={17} color="#F8FAFC" />
        </button>
      </div>

      <div style={{
        position: 'absolute', top: 188, right: 16,
        ...glassCard(true),
        padding: '12px 14px', minWidth: 124,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: sAccent }}>
            {s.label}
          </span>
        </div>
        <div style={{ fontSize: 34, fontWeight: 800, color: '#F8FAFC', lineHeight: 1, letterSpacing: -1 }}>
          {s.minutes}<span style={{ fontSize: 14, fontWeight: 600, color: '#94A3B8', marginLeft: 4 }}>min</span>
        </div>
        <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 4, fontWeight: 500 }}>arrives {s.eta}</div>
      </div>

      <div style={{
        position: 'absolute', bottom: 110, left: 16, right: 16,
        ...glassCard(true),
        padding: 14,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Avatar initials={DRIVER.initials} color={accent} size={44} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#F8FAFC' }}>{DRIVER.name}</div>
            <div style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500, marginTop: 1 }}>{DRIVER.role}</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={iconCircleBtn(true)}>
              <MessageIcon size={17} color="#F8FAFC" />
            </button>
            <button style={{ ...iconCircleBtn(true), background: accent, border: 'none' }}>
              <PhoneIcon size={17} color="#0B0F14" />
            </button>
          </div>
        </div>
      </div>
      <TopHeader dark={true} accent={accent} />
      <BottomTabs dark={true} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 5 — Bottom sheet · Dark · Friendly
// ─────────────────────────────────────────────────────────────
function V5SheetDark({ state = 'en_route', accent = '#818CF8' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#F8FAFC' }}>
      <MapBackground dark={true} accent={accent} showRoute={state !== 'dropped_off'} />

      <div style={{ position: 'absolute', top: 122, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
        <button style={glassPillBtn(true)}>
          <ChevronLeft size={18} color="#F8FAFC" />
        </button>
        <div style={{ ...glassCard(true), padding: '8px 14px 8px 8px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <KidStack dark={true} size={26} />
          <span style={{ fontSize: 13, fontWeight: 700, color: '#F8FAFC' }}>Both kids</span>
          <ChevronDown size={14} color="#94A3B8" />
        </div>
        <button style={glassPillBtn(true)}>
          <MoreIcon size={18} color="#F8FAFC" />
        </button>
      </div>

      <div style={{
        position: 'absolute', bottom: 94, left: 0, right: 0,
        background: '#161D27',
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        boxShadow: '0 -12px 40px rgba(0,0,0,0.4)',
        padding: '12px 20px 20px',
        borderTop: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ width: 38, height: 5, borderRadius: 3, background: '#3B4658', margin: '0 auto 14px' }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 12, fontWeight: 700, color: sAccent, textTransform: 'uppercase', letterSpacing: 0.6 }}>
            {s.label}
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 4 }}>
          {state === 'dropped_off' ? (
            <span style={{ fontSize: 48, fontWeight: 800, color: '#F8FAFC', letterSpacing: -1.5, lineHeight: 1 }}>
              At school
            </span>
          ) : (
            <>
              <span style={{ fontSize: 64, fontWeight: 800, color: '#F8FAFC', letterSpacing: -2, lineHeight: 1 }}>
                {s.minutes}
              </span>
              <span style={{ fontSize: 22, fontWeight: 600, color: '#94A3B8' }}>min away</span>
            </>
          )}
        </div>
        <div style={{ fontSize: 14, color: '#94A3B8', marginBottom: 18, fontWeight: 500 }}>
          Arrives at <span style={{ color: '#F8FAFC', fontWeight: 700 }}>{s.eta}</span> · {s.detail.split('·')[0].trim()}
        </div>

        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          background: '#1F2734', borderRadius: 18, padding: 12, marginBottom: 12,
          border: '1px solid rgba(255,255,255,0.05)',
        }}>
          <Avatar initials={DRIVER.initials} color={accent} size={42} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#F8FAFC' }}>{DRIVER.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
              <StarIcon size={11} color="#F59E0B" fill="#F59E0B" />
              <span style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>{DRIVER.rating} · {DRIVER.trips} trips</span>
            </div>
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.06)', borderRadius: 999, padding: '6px 10px',
            display: 'flex', alignItems: 'center', gap: 5,
            border: '1px solid rgba(255,255,255,0.08)',
          }}>
            <BusIcon size={13} color={accent} />
            <span style={{ fontSize: 12, fontWeight: 700, color: accent }}>{DRIVER.bus}</span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button style={{
            flex: 1, height: 50, borderRadius: 16, border: '1.5px solid rgba(255,255,255,0.1)',
            background: 'rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            fontSize: 14, fontWeight: 700, color: '#F8FAFC', cursor: 'pointer',
          }}>
            <MessageIcon size={17} color="#F8FAFC" />
            Message
          </button>
          <button style={{
            flex: 1, height: 50, borderRadius: 16, border: 'none',
            background: accent, color: '#0B0F14',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            fontSize: 14, fontWeight: 700, cursor: 'pointer',
            boxShadow: `0 8px 22px ${accent}55`,
          }}>
            <PhoneIcon size={17} color="#0B0F14" />
            Call driver
          </button>
        </div>
      </div>
      <TopHeader dark={true} accent={accent} />
      <BottomTabs dark={true} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VARIATION 6 — Top banner + Action bar · Dark · Utility
// ─────────────────────────────────────────────────────────────
function V6BannerDark({ state = 'en_route', accent = '#818CF8' }) {
  const s = STATE_LABELS[state];
  const sAccent = stateAccent(state, accent);
  return (
    <div style={{ position: 'absolute', inset: 0, color: '#F8FAFC' }}>
      <MapBackground dark={true} accent={accent} showRoute={state !== 'dropped_off'} />

      <div style={{
        position: 'absolute', top: 122, left: 12, right: 12,
        background: '#161D27',
        paddingTop: 4,
        boxShadow: '0 6px 24px rgba(0,0,0,0.4)',
        borderRadius: 18,
        border: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 18px 0' }}>
          <PingDot color={sAccent} />
          <span style={{ fontSize: 11, fontWeight: 700, color: sAccent, textTransform: 'uppercase', letterSpacing: 0.6 }}>
            {s.label}
          </span>
          <span style={{ marginLeft: 'auto', fontSize: 11, color: '#94A3B8', fontWeight: 600 }}>
            Updated 12s ago
          </span>
        </div>

        <div style={{ padding: '4px 18px 16px', display: 'flex', alignItems: 'flex-end', gap: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 600, marginBottom: 2 }}>ARRIVES</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <div style={{ fontSize: 34, fontWeight: 800, color: '#F8FAFC', letterSpacing: -1, lineHeight: 1 }}>
                {s.eta}
              </div>
              {state !== 'dropped_off' && (
                <div style={{
                  background: sAccent + '22', color: sAccent,
                  borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 700,
                }}>
                  in {s.minutes} min
                </div>
              )}
            </div>
            <div style={{ fontSize: 12, color: '#94A3B8', marginTop: 4, fontWeight: 500 }}>{s.detail}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <KidStack dark={true} size={28} />
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 600, marginTop: 4 }}>2 onboard</div>
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: 100, left: 12, right: 12,
        background: '#161D27',
        borderRadius: 18,
        boxShadow: '0 -6px 24px rgba(0,0,0,0.4)',
        padding: '14px 18px 14px',
        border: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <Avatar initials={DRIVER.initials} color={accent} size={40} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#F8FAFC' }}>{DRIVER.name}</div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 500, marginTop: 1 }}>
              Driver · License DLR‑4421
            </div>
          </div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 4,
            background: 'rgba(255,255,255,0.06)', borderRadius: 8, padding: '5px 9px',
            fontSize: 11, fontWeight: 700, color: '#F8FAFC',
          }}>
            <BusIcon size={12} color="#F8FAFC" />
            {DRIVER.bus}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={squareBtn(true)}>
            <PhoneIcon size={16} color="#F8FAFC" />
            <span>Call</span>
          </button>
          <button style={squareBtn(true)}>
            <MessageIcon size={16} color="#F8FAFC" />
            <span>Text</span>
          </button>
          <button style={squareBtn(true)}>
            <ShieldIcon size={16} color="#F87171" />
            <span style={{ color: '#F87171' }}>Report</span>
          </button>
        </div>
      </div>
      <TopHeader dark={true} accent={accent} />
      <BottomTabs dark={true} accent={accent} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Shared style fns
// ─────────────────────────────────────────────────────────────
function glassCard(dark) {
  return {
    borderRadius: 22,
    background: dark ? 'rgba(22,29,39,0.78)' : 'rgba(255,255,255,0.82)',
    backdropFilter: 'blur(20px) saturate(180%)',
    WebkitBackdropFilter: 'blur(20px) saturate(180%)',
    boxShadow: dark
      ? '0 8px 28px rgba(0,0,0,0.4), inset 0 0 0 1px rgba(255,255,255,0.05)'
      : '0 6px 24px rgba(15,23,42,0.10), inset 0 0 0 1px rgba(255,255,255,0.5)',
  };
}
function glassPillBtn(dark) {
  return {
    width: 44, height: 44, borderRadius: 22,
    border: 'none', cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    ...glassCard(dark),
  };
}
function iconCircleBtn(dark) {
  return {
    width: 40, height: 40, borderRadius: 20,
    background: dark ? 'rgba(255,255,255,0.08)' : '#F4F6F9',
    border: dark ? '1px solid rgba(255,255,255,0.06)' : 'none',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer',
  };
}
function squareBtn(dark) {
  return {
    flex: 1, height: 44, borderRadius: 12,
    background: dark ? 'rgba(255,255,255,0.06)' : '#F1F5F9',
    border: dark ? '1px solid rgba(255,255,255,0.06)' : '1px solid #E5E9EF',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
    fontSize: 13, fontWeight: 700, color: dark ? '#F8FAFC' : '#0F172A',
    cursor: 'pointer',
  };
}

Object.assign(window, { V1FloatingLight, V2SheetLight, V3BannerLight, V4FloatingDark, V5SheetDark, V6BannerDark });
