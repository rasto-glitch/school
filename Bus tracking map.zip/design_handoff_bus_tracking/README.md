# Handoff: Bus Tracking Screen Redesign

## Overview

Redesign of `mobile/src/screens/parent/BusTrackingScreen.tsx`. The current screen is a vertical scroll of stacked cards (driver info → ETA → small embedded map → pickup row → residence form). The redesign promotes the **map to fill the entire screen** between the existing `ParentTabs` chrome (header + bottom nav), with a **floating top banner** (status + ETA) and **floating bottom action bar** (driver + actions) layered over the map.

Two variations are delivered: **light mode** and **dark mode** (`V3BannerLight` and `V6BannerDark` in `variations.jsx`). The screen already supports both themes via the existing `useColors()` / `useIsDark()` store.

## About the Design Files

The files in this bundle are **design references created in HTML/React** — prototypes showing intended look, layout, and behavior. They are **not production code to copy directly**.

The task is to **recreate the screen inside the existing `mobile/` React Native app**, using its established patterns (StyleSheet, `useColors()`, `useIsDark()`, `lucide-react-native`, `react-native-maps`, `useSafeAreaInsets`). Components like `<TopHeader>` and `<BottomTabs>` from `chrome.jsx` are **only present in the HTML preview** to show context — in the real app these are already provided by `ParentTabs.tsx` and should not be re-implemented inside `BusTrackingScreen.tsx`.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, and component shapes. The developer should match the design pixel-for-pixel inside the existing RN environment.

---

## Target file

`mobile/src/screens/parent/BusTrackingScreen.tsx`

All existing data wiring (`parentApi.getBusLocation`, `parentApi.getDriverInfo`, `parentApi.getPickupLocation`, `parentApi.getChildren`, socket.io `watchDriver` + `locationUpdate` + `driveEnded` + `busAlert`, ETA computation via `computeETA`, the `MapErrorBoundary`) **must be preserved unchanged**. Only the rendering layer changes.

### Things to move OFF this screen

The current screen embeds three secondary concerns that no longer fit a map-first layout:

1. **Pickup location row** (the `TouchableOpacity` that navigates to `SetPickupLocation`)
2. **Residence type + block number form** (the inline `residenceCard`)
3. **Refresh button** (the header refresh icon)

Move all three into **Settings** (or a "Bus & Pickup" subsection of Settings). The existing `SetPickupLocationScreen` is unchanged; just route to it from Settings instead of this screen. The refresh button is no longer needed — the screen already polls every 30s via the existing `useEffect`.

---

## Layout

The screen is `position: 'absolute', inset: 0` under the existing `ParentTabs` header (56px + safe top) and tab bar (60px + safe bottom). The map fills the absolute viewport edge-to-edge; banner and action bar are absolutely positioned and respect the tab bar / header insets via `useSafeAreaInsets()`.

```
┌──────────────────────────────────────┐
│  [ParentTabs header — existing]      │  ← already provided
├──────────────────────────────────────┤
│  ┌────────────────────────────────┐  │
│  │ [ Status banner — top card  ]  │  │  top: insets.top + 56 + 12
│  └────────────────────────────────┘  │
│                                      │
│        MapView (edge-to-edge)        │
│                                      │
│  ┌────────────────────────────────┐  │
│  │ [ Driver + action bar — card ] │  │  bottom: insets.bottom + 60 + 12
│  └────────────────────────────────┘  │
├──────────────────────────────────────┤
│  [ParentTabs bottom nav — existing]  │  ← already provided
└──────────────────────────────────────┘
```

Both overlay cards have horizontal margin **12px** from screen edges.

---

## Component spec

### 1. Map (background)

- Existing `<MapView provider={PROVIDER_DEFAULT}>` wrapped in `<MapErrorBoundary>`.
- `style={{ ...StyleSheet.absoluteFillObject }}` — fills behind the overlays.
- Keep current `key`, `initialRegion`, and the three existing `<Marker>`s (bus marker with `busMarker` styling, home pin, pickup/parent pin). No marker changes.
- One **new** addition optional: a `<Polyline>` between the bus and the pickup/parent marker, using `coordinates` derived from `busData.location` → `etaTarget`, `strokeColor={colors.primary}`, `strokeWidth={4}`, with a dashed `lineDashPattern={[2, 8]}` if Google Maps is available. The HTML mock shows an animated dashed route; in RN a static dashed polyline is acceptable.

### 2. Status banner (top card)

A floating white (light) / `#161D27` (dark) card positioned **below the header**. See `V3BannerLight` and `V6BannerDark` in `variations.jsx`.

**Position**
```js
position: 'absolute',
top: insets.top + 56 + 12,   // safe area + ParentTabs header + 12px gap
left: 12, right: 12,
```

**Container**
- `backgroundColor`: light = `#FFFFFF`; dark = `#161D27`
- `borderRadius: 18`
- Light shadow: `shadowColor: '#000', shadowOpacity: 0.10, shadowOffset: { width: 0, height: 6 }, shadowRadius: 24, elevation: 6`
- Dark border: `borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)'`
- Internal padding: `paddingTop: 8, paddingHorizontal: 18, paddingBottom: 16`

**Status strip (row 1)**
- Pulsing dot — 8×8 circle in `stateAccent` color (see Trip States below), wrapped by an absolutely-positioned 16×16 same-color circle at `opacity: 0.25` animating scale 1 → 1.8 over 1.6s (use `Animated.loop`). In RN, the `busPulse` keyframes in `Bus Tracking.html` line ~20 translate to:
  ```js
  Animated.loop(
    Animated.timing(pulseAnim, { toValue: 1, duration: 1600, useNativeDriver: true })
  ).start();
  // transform: [{ scale: pulseAnim.interpolate({ inputRange: [0,1], outputRange: [0.7, 1.8] }) }]
  // opacity: pulseAnim.interpolate({ inputRange: [0, 0.8, 1], outputRange: [0.6, 0, 0] })
  ```
- Status label — see Trip States table below. `fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.6, color: stateAccent`
- "Updated 12s ago" on the right — `marginLeft: 'auto', fontSize: 11, fontWeight: '600'`. Light color `#64748B`, dark `#94A3B8`. **Wire to real "seconds since last `locationUpdate`"** — increment each second from a `lastUpdatedAt` ref.

**Main row (row 2)**
Flex row, `alignItems: 'flex-end', gap: 14`.

Left column (flex 1):
- Caption "ARRIVES" — `fontSize: 11, fontWeight: '600', marginBottom: 2`. Light `#64748B`, dark `#94A3B8`.
- ETA time + chip — flex row, `alignItems: 'baseline', gap: 6`:
  - Time: `fontSize: 34, fontWeight: '800', letterSpacing: -1, lineHeight: 34`. Light `#0F172A`, dark `#F8FAFC`.
  - Chip: `backgroundColor: stateAccent + '18'` (light) / `+ '22'` (dark), `color: stateAccent`, `borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4, fontSize: 12, fontWeight: '700'`. Text: `"in 4 min"`. Hide chip when state is `dropped_off`.
- Detail line: `fontSize: 12, fontWeight: '500', marginTop: 4`. Light `#64748B`, dark `#94A3B8`. Example: "Bus is 0.8 mi away · 3 stops ahead".

Right column:
- KidStack — overlapping circle avatars of the parent's children riding this bus. Each circle is 28×28, white ring (`borderColor: '#FFFFFF'` light / `'#1B232E'` dark, `borderWidth: 3` simulated by box-shadow in HTML; in RN use `borderWidth: 2.5`). Overlap by `marginLeft: -10` for every avatar after the first. Initials in 700 weight, font-size 40% of circle. Background colors: `['#F472B6', '#60A5FA', '#34D399', '#FBBF24', ...]` cycled by child index.
- Below stack: `"2 onboard"` (or `"N onboard"` if multiple children, `"On the bus"` if 1) — `fontSize: 11, fontWeight: '600', marginTop: 4, textAlign: 'right'`.

### 3. Driver + action bar (bottom card)

**Position**
```js
position: 'absolute',
bottom: insets.bottom + 60 + 12,  // safe bottom + ParentTabs tab bar + 12px gap
left: 12, right: 12,
```

**Container**
- Same fill/shadow/border treatment as the top banner.
- Padding: `paddingTop: 14, paddingHorizontal: 18, paddingBottom: 14`

**Driver row (row 1)**
Flex row, `alignItems: 'center', gap: 12, marginBottom: 12`.

- Avatar — 40×40 circle, background `accent`, white initials (`fontSize: 16, fontWeight: '700'`). Use first/last initial of `driverInfo.fullName`. Box shadow: `shadowOpacity: 0.18, shadowOffset: { width: 0, height: 2 }, shadowRadius: 8`.
- Middle column (flex 1):
  - Name: `fontSize: 14, fontWeight: '700'`. Light `#0F172A`, dark `#F8FAFC`.
  - Sub: `fontSize: 11, fontWeight: '500', marginTop: 1`. Light `#64748B`, dark `#94A3B8`. Text: `"Driver · License {licenseNumber}"` — pull from `driverInfo.licenseNumber`, fallback `"Driver"` when missing.
- Bus badge — flex row, `gap: 4, paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8`. Light `backgroundColor: '#F1F5F9', color: '#0F172A'`. Dark `backgroundColor: 'rgba(255,255,255,0.06)', color: '#F8FAFC'`. Icon = `Bus` from lucide, size 12. Text `fontSize: 11, fontWeight: '700'` showing `driverInfo.buses.busNumber` prefixed with `#`. Hide entire badge if no bus number.

**Action row (row 2)**
Flex row, `gap: 8`. Three equal-width buttons (each `flex: 1, height: 44`).

| Button  | Action                                                    | Icon    | Label color (light/dark) |
|---------|-----------------------------------------------------------|---------|--------------------------|
| Call    | `Linking.openURL('tel:' + driverInfo.phoneNumber)` if set | `Phone` | `#0F172A` / `#F8FAFC`    |
| Text    | `Linking.openURL('sms:' + driverInfo.phoneNumber)` if set | `MessageSquare` | `#0F172A` / `#F8FAFC` |
| Report  | Open an Alert with "Report an issue" prompt → POSTs to a new endpoint (out of scope — leave a `TODO` and log to console for now) | `Shield` | `#EF4444` / `#F87171`    |

Each button styling:
- `borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6`
- Icon size 16, label `fontSize: 13, fontWeight: '700'`
- Light: `backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E5E9EF'`
- Dark: `backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)'`

Disable Call/Text when `!driverInfo?.phoneNumber` (opacity 0.5).

---

## Trip states

Drive the top banner from the same state the existing screen derives. Map the screen's current branches into one enum:

| State (enum)  | Trigger (existing logic)                                              | Label         | Accent color (`stateAccent`) | Chip visible | Detail line                                |
|---------------|-----------------------------------------------------------------------|---------------|------------------------------|--------------|--------------------------------------------|
| `en_route`    | `busData.location.isDriving && minutesToETA > 2`                      | "En route"    | `colors.primary`             | yes          | `"Bus is {dist} mi away · {n} stops ahead"` |
| `arriving`    | `busData.location.isDriving && minutesToETA <= 2`                     | "Arriving soon" | `colors.warning` (#F59E0B) | yes          | `"Bus turning onto {nearestStreet}"` *or* `"Less than 2 min away"` |
| `boarded`     | Server emits `studentBoarded` (new event)                             | "On the bus"  | `colors.primary`             | yes          | `"Heading to {school.name}"`                |
| `dropped_off` | Server emits `studentDroppedOff` *or* `!isActive && lastTripCompleted`| "Dropped off" | `colors.success` (#10B981)   | no — hide entire ETA chip; ETA becomes the drop-off time | `"Arrived at {school.name}"` |

`stateAccent` lives in `variations.jsx` line ~22. The HTML uses string fallbacks; in RN, map it through `theme.ts` colors so it auto-themes.

When state is `dropped_off`, the ETA *time* should be the timestamp of the drop-off, and the inline chip is removed.

---

## Empty / non-active states

The current screen has three non-active surfaces — keep them, restyled to match the new card vocabulary:

1. **No active bus** (`!isActive && !absent && !loading`) — render the top banner only, with status label `"Bus not active"` (color = `colors.textMuted`), no ETA chip, and detail line `"Tracking starts when the driver begins the route"`. Show the driver card as normal (driver info comes from `staticDriverInfo` when there's no live trip). Hide the map dashed polyline.
2. **Absent** (`absent === true`) — replace the top banner with an amber warning card: same shape, `backgroundColor: colors.warningLight` (light) / `'#3A2E16'` (dark), `borderColor: '#FDE68A'`, icon `AlertCircle` 18px at left, message `t('bus.absent_message')`. Hide the bottom driver card.
3. **Loading** (`loading === true && !busData`) — show a centered `ActivityIndicator` over the map and keep the static driver card visible.

---

## Multi-child support

The current screen has a child selector (`children.length > 1`). In the redesign, all the parent's children **on this bus** are shown together as the KidStack in the top banner — no selector needed. If a parent has children on **different buses**, render a tap-to-switch pill in the **header area** outside this screen (parent `ParentTabs` header chrome — out of scope here) **or** add a compact dropdown to the right of `"2 onboard"`:

- Tappable area on KidStack opens an action sheet listing the parent's children grouped by bus (`Bus #B-204: Maya, Leo` / `Bus #B-211: Sofia`). Tapping a bus row changes `selectedChild` and the screen re-fetches.

For initial implementation, **omit the cross-bus switcher** — the user confirmed multiple children would be on the same bus.

---

## Interactions & behavior

- **Polling** unchanged — `fetchBus` every 30s, socket subscription on `driverId`.
- **Tap top banner** — no action.
- **Tap bus badge in driver card** — no action.
- **Tap Call** — `Linking.openURL('tel:' + driverInfo.phoneNumber)`.
- **Tap Text** — `Linking.openURL('sms:' + driverInfo.phoneNumber)`.
- **Tap Report** — `Alert.alert('Report an issue', '...', [{text: 'Cancel'}, {text: 'Send', onPress: () => {/* TODO */}}])`.
- **Pulsing dot** — Animated.loop, 1600ms cycle, scales 0.7 → 1.8, opacity 0.6 → 0.
- **"Updated 12s ago"** — interval that increments every 1s; reset whenever `busData.location` changes (via socket `locationUpdate`).

---

## State management

All existing state in `BusTrackingScreen.tsx` is preserved:
- `staticDriverInfo`, `children`, `selectedChild`, `busData`, `absent`, `loading`, `parentLocation`, `busSpeed`
- Derived: `isActive`, `driverInfo`, `etaTarget`, `etaTime`, `mapInitialRegion`

**Remove** (move to Settings):
- `hasPickupLocation`, `pickupCoords`, `residenceType`, `blockNumber`, `residenceDirty`, `savingResidence`

**Add**:
- `lastUpdatedAt: number` (ms) — set on every socket `locationUpdate`. Drive the "Updated Xs ago" string.
- `pulseAnim: Animated.Value` — for the status dot.

---

## Design tokens

Pulled from `mobile/src/theme.ts` — **use these, don't introduce new ones**.

### Colors

| Token (light)             | Hex        | Used for                              |
|---------------------------|------------|---------------------------------------|
| `colors.primary`          | `#4F46E5`  | accent / `en_route` / `boarded` state |
| `colors.warning`          | `#F59E0B`  | `arriving` state                      |
| `colors.success`          | `#10B981`  | `dropped_off` state                   |
| `colors.danger`           | `#EF4444`  | Report button                         |
| `colors.card`             | `#FFFFFF`  | banner / action bar fill              |
| `colors.text`             | `#111827`  | primary text (close to `#0F172A`)     |
| `colors.textSecondary`    | `#6B7280`  | sub text                              |
| `colors.textMuted`        | `#9CA3AF`  | inactive/idle                         |
| `colors.bg`               | `#F2F2F7`  | screen bg behind map (map covers it)  |
| `colors.border`           | `#E5E7EB`  | button border                         |
| `colors.borderLight`      | `#F3F4F6`  | button bg                             |

Dark mode equivalents come from the existing `useColors()` store. Where the HTML uses literal hex (`#161D27`, `#F8FAFC`, `#94A3B8`, `rgba(255,255,255,0.06)`), prefer the matching `useColors()` value if one exists.

### Typography

All from `mobile/src/theme.ts`:

| Component           | Theme token | Weight   |
|---------------------|-------------|----------|
| ETA time (big)      | custom 34   | `'800'`  |
| Status label        | `font.xs` 11 | `'700'`, uppercase, `letterSpacing: 0.6` |
| Caption "ARRIVES"   | `font.xs` 11 | `'600'`  |
| Driver name        | `font.sm` 13–14 | `'700'`|
| Driver sub        | 11 (custom)  | `'500'`  |
| Detail line       | `font.xs`–`font.sm` 12 | `'500'` |
| Button label      | `font.sm` 13 | `'700'`  |
| Updated label     | 11 (custom)  | `'600'`  |

### Spacing

`spacing.xs=4, sm=8, md=16, lg=24` — already imported. Use these where they fit; for the 12px gap between overlays and the chrome use `12` literal (between `spacing.sm=8` and `spacing.md=16` — neither matches exactly).

### Radius

`radius.md=12` for action buttons. The big card uses **18** (literal) — note this is **not** in `radius.ts`; either add it as `radius.lg = 18` (currently `radius.lg = 16`) or use literal.

### Shadows

Use existing `shadow.md` for both cards. Verify on Android — `elevation: 3` is fine.

---

## Assets

- **Icons** — all from `lucide-react-native` (already a dependency). Used: `Bus`, `Phone`, `MessageSquare`, `Shield`, `AlertCircle`, `Star` (optional for driver rating if you add it later).
- **No image assets.** Avatars are initials; school logo in the chrome is provided by the existing `HeaderBrand` component.

---

## Files

In this bundle:

- `Bus Tracking.html` — open this in a browser to interact with the design (uses Babel; no install). The design canvas shows both light and dark side-by-side; the **Tweaks** floating panel toggles trip state and accent color.
- `app.jsx` — design-canvas wiring + tweaks panel
- `variations.jsx` — **the canonical reference**. `V3BannerLight` (line ~265) and `V6BannerDark` (line ~545). Style helpers `glassCard`, `squareBtn`, `stateAccent`, `KidStack`, `PingDot`, `Avatar` at top of file.
- `chrome.jsx` — `TopHeader` and `BottomTabs` shown for context only. **Do not port** — the real `ParentTabs.tsx` already provides this chrome.
- `map.jsx` — stylized SVG map background. **Do not port** — the real screen uses `react-native-maps` `MapView`.
- `icons.jsx` — lucide-style SVG icons for the HTML preview only. **Do not port** — use `lucide-react-native` in RN.
- `ios-frame.jsx`, `design-canvas.jsx`, `tweaks-panel.jsx` — preview chrome only. **Do not port.**

Files in the existing repo that the redesign affects:

- `mobile/src/screens/parent/BusTrackingScreen.tsx` — replace the rendering layer; keep all data wiring.
- `mobile/src/screens/parent/SettingsScreen.tsx` — add a "Bus & pickup" section with two rows: "Pickup location" (navigates to `SetPickupLocation`) and "Residence type & block number" (a new sub-screen or inline modal that calls `parentApi.updatePickupLocation` with the residenceType/blockNumber fields).
- `mobile/src/i18n/locales/en.json`, `ar.json`, `ku.json` — add any new strings (`bus.report_issue`, `bus.updated_seconds_ago`, etc.) to all three.

No backend changes required for the core redesign. Optional later: add `studentBoarded` / `studentDroppedOff` socket events to drive states 3 & 4 in real time.
