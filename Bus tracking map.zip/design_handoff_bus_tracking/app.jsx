// Main app — final selected variations: Banner (light) + Banner (dark)

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "state": "en_route",
  "lightAccent": "#4F46E5",
  "darkAccent": "#818CF8"
}/*EDITMODE-END*/;

const STATE_OPTIONS = [
  { value: 'en_route',    label: 'En route' },
  { value: 'arriving',    label: 'Arriving' },
  { value: 'boarded',     label: 'On the bus' },
  { value: 'dropped_off', label: 'Dropped off' },
];

const LIGHT_ACCENTS = ['#4F46E5', '#0EA5E9', '#EA580C', '#10B981'];
const DARK_ACCENTS  = ['#818CF8', '#38BDF8', '#FB923C', '#34D399'];

function Phone({ children, dark }) {
  return (
    <IOSDevice width={402} height={874} dark={dark}>
      <div style={{ position: 'absolute', inset: 0 }}>
        {children}
      </div>
    </IOSDevice>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const state = tweaks.state || 'en_route';

  return (
    <>
      <DesignCanvas
        title="Bus Tracking — Final"
        subtitle="Map-first layout · Banner header + action bar overlay · Light & Dark"
      >
        <DCSection id="banner" title="Banner overlay — final pick">
          <DCArtboard id="v3" label="Light theme" width={402} height={874}>
            <Phone dark={false}>
              <V3BannerLight state={state} accent={tweaks.lightAccent} />
            </Phone>
          </DCArtboard>
          <DCArtboard id="v6" label="Dark theme" width={402} height={874}>
            <Phone dark={true}>
              <V6BannerDark state={state} accent={tweaks.darkAccent} />
            </Phone>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Trip state">
          <TweakSelect
            label="State"
            value={state}
            options={STATE_OPTIONS}
            onChange={v => setTweak('state', v)}
          />
        </TweakSection>
        <TweakSection label="Accent color">
          <TweakColor
            label="Light theme"
            value={tweaks.lightAccent}
            options={LIGHT_ACCENTS}
            onChange={v => setTweak('lightAccent', v)}
          />
          <TweakColor
            label="Dark theme"
            value={tweaks.darkAccent}
            options={DARK_ACCENTS}
            onChange={v => setTweak('darkAccent', v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
